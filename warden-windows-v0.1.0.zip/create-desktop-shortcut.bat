@echo off
REM Creates a real Desktop shortcut for Warden that you can double-click
REM like any other app icon. Run this once after unzipping.

setlocal
set "SCRIPT_DIR=%~dp0"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$WshShell = New-Object -ComObject WScript.Shell; " ^
  "$Shortcut = $WshShell.CreateShortcut(\"$env:USERPROFILE\Desktop\Warden.lnk\"); " ^
  "$Shortcut.TargetPath = '%SCRIPT_DIR%run.bat'; " ^
  "$Shortcut.WorkingDirectory = '%SCRIPT_DIR%'; " ^
  "$Shortcut.IconLocation = '%SystemRoot%\System32\shell32.dll,44'; " ^
  "$Shortcut.Description = 'Warden — AI red-teaming test runner'; " ^
  "$Shortcut.Save()"

echo.
echo Done — look for "Warden" on your Desktop. Double-click it any time to launch Warden.
pause
